<?php
require_once("typingadmin/koneksi.php");
?>

<!doctype HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>phonetictyping.com</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo _DIR_PATH_;?>keyboard/css/style.css" rel="stylesheet" type="text/css">
	
	<link rel="stylesheet" href="<?php echo _DIR_PATH_;?>keyboard/css/jquery.bxslider.css" />
	
	</head>
<body>