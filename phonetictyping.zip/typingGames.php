<html>
<body>
<center>
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" width="810" height="685" id="Pertamax" align="middle">
	<param name="allowScriptAccess" value="sameDomain" />
	<param name="allowFullScreen" value="false" />
	<param name="movie" value="typingGames.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#000000" />	<embed src="typingGames.swf" quality="high" bgcolor="#000000" width="810" height="685" name="Pertamax" align="middle" allowScriptAccess="sameDomain" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.adobe.com/go/getflashplayer" />
</object>
</center>
</body>
</html>