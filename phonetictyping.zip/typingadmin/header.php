﻿<?php session_start(); ?>
<table BORDER=2 RULES=ALL FRAME=BOX bgcolor='white' align="center" width="700">
	
	<tr>
		
		<!--
		<td align="center" width="100" bgcolor="white">
			<img width="100" height="160" src="http://localhost/app/typingadmin/image/logo.jpg"/>
		</td>
		<td align="center" colspan="2" valign="center" height="100" bgcolor="white">
			<img width="600" height="160" src="http://localhost/app/typingadmin/image/typing-test.jpg" alt="banner" />
		</td>
		-->
		
		
		<!--<td align="center" width="100" bgcolor="white">
			<img src="http://www.comicedu.com/typing/typingadmin/image/logo.jpg"/>
		</td>
		<td align="center" colspan="2" valign="center" height="100" bgcolor="white">
			<img src="http://www.comicedu.com/typing/typingadmin/image/typing-test.jpg" width="600" height="160" alt="banner" />
		</td>-->
		
	</tr>
	
	<tr bgcolor='orange'>
		<td align="right" colspan="3">
			<font color="5261E0"><b>
			
			<!--
			<a href='http://localhost/app/typingadmin/index.php'>Home</a> | 
			<a href='http://localhost/app/typingadmin/signout.php'>Signout </a> | 
			-->
			
			<!--<a href='http://www.comicedu.com/typing/typingadmin/index.php'>Home</a> | 
			<a href='http://www.comicedu.com/typing/typingadmin/signout.php'>Signout </a> | -->
			
			
			<a href='http://205.147.97.190/typing/keyboard/typingadmin/index.php'>Home</a> | 
			<a href='http://205.147.97.190/typing/keyboard/typingadmin/signout.php'>Signout </a>
			
			</b>
			</font>
		</td>
	</tr>
	
</table>