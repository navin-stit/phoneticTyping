﻿<html>
	<frameset cols="1">
		<frame src="keteranganInfo.php">
	</frameset>
</html>
