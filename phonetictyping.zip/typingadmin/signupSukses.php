﻿<html>
<head><title>Sign up Success</title>
</head>

<body background="image/bg.gif">
<br/><br/><br/><br/>

<table border="1" align="center" width="700" bgcolor="white">
	<tr><td>
	<center>
		<br/><br/>
		<h3><b><font color="blue">Register Sukses !!!</font></b></h3>
		Namun Anda belum bisa login sebelum nama Anda di verifikasi oleh pimpinan Anda<br/>
		Silahkan berikan Nama Anda <b><font color="blue"><?=$_GET['namaLogin'];?></font></b> untuk di verifikasi<br/>
		<a href="index.php">Klik disini untuk kembali ke Menu utama</a>
		<br/><br/><br/><br/>
	</center>
	</td></tr>
</table>

</body>

</html>
<?

?>