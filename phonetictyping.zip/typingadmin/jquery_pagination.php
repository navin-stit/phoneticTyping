<?php
require_once("koneksi.php");
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta http-equiv="x-ua-compatible" content="ie=edge">

        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
        <!-- Bootstrap core CSS -->
        <link href="../slider_layout/css/bootstrap.min.css" rel="stylesheet">
        <!-- Material Design Bootstrap -->
        <link href="../slider_layout/css/compiled-4.7.6.min.css" rel="stylesheet">
        <!-- Your custom styles (optional) -->
        <link href="../slider_layout/css/addons/datatables.min.css" rel="stylesheet">
        <link href="../slider_layout/css/style.css" rel="stylesheet">
    </head>

    <body>


        <?php
    require_once("koneksi.php");
    ?>
        <div class="container">
            <div class="row">
                <form id='frmReportLesson' action='' method='POST' enctype='multipart/form-data'
                    id='frmPhotoUpload' name='frmPhotoUpload'>

                    <!-- <button type="button" value="submit" class="clickme">Submit</button>-->
                    <table id="dtBasicExample" class="table table-striped" cellspacing="0" width="100%">

                        <thead>
                            <tr>
                                <td>Report Student Lesson
                                </td>
                            </tr>
                            <tr>
                                <td> Choose Student :
                                    <?php
                            $caridata = mysqli_query($con,"SELECT username FROM user_allow ORDER BY username ASC");
                            ?>
                                    <select name="cbStudent" id="cbStudent" style="display:block!important" onchange="this.form.submit()">
                                        <option value=''>== Student ==</option>
                                        <?php 
                                    while ($row = mysqli_fetch_array($caridata, MYSQLI_BOTH)) {
                                        if (isset($_POST['cbStudent'])) { 
                                            if ($row['username'] == $_POST['cbStudent']) {
                                                echo "<option value='".$row['username']."' selected>".$row['username']."</option>";
                                            } else {
                                                echo "<option value='".$row['username']."'>".$row['username']."</option>";
                                            }
                                        } else {
                                            echo "<option value='".$row['username']."'>".$row['username']."</option>";
                                        }
                                    }
                                    ?>
                              
                                    </select>
                                </td>
                            </tr>
                                    <tr>
                                <th class="th-sm">Date Record
                                </th>
                                <th class="th-sm">Score
                                </th>
                                <th class="th-sm">Lesson Complete
                                </th>
                                <th class="th-sm">Time Complete
                                </th>

                            </tr>

                        </thead>
                        <tbody>
                            <?php 
                        if(isset($_POST['cbStudent'])) { 
                           // echo "hello";exit;
                     $carirecord = mysqli_query($con, "SELECT * FROM user_record WHERE nama='".$_POST['cbStudent']."'
				     ORDER BY tanggal ASC");
				    $tanggalcatat = "";
				    while ($rows = mysqli_fetch_array($carirecord,MYSQLI_BOTH)) {
                        //print_r($rows);exit;
                    ?>
                            <tr>
                            <td>
                            <?php 
                            if($tanggalcatat!=$rows['recorddate']) {
                                echo $rows['recorddate'];
                                $tanggalcatat = $rows['recorddate'];
                            }
                            ?>
                            </td>
                                <td><?php echo $rows['nama'];?></td>
                                <td><?php echo $rows['score'];?></td>
                                <td><?php echo substr($rows['tanggal'],11,8);?></td>

                            </tr>
                            <?php }
                        }
                        ?>
                        </tbody>

                    </table>
                </form>
            </div>
        </div>


        <!-- SCRIPTS -->
        <!-- JQuery -->
        <script type="text/javascript" src="../slider_layout/js/jquery-3.3.1.min.js"></script>
        <!-- Bootstrap tooltips -->
        <script type="text/javascript" src="../slider_layout/js/popper.min.js"></script>
        <!-- Bootstrap core JavaScript -->
        <script type="text/javascript" src="../slider_layout/js/bootstrap.min.js"></script>
        <!-- MDB core JavaScript -->
        <script type="text/javascript" src="../slider_layout/js/mdb.min.js"></script>
        <script type="text/javascript" src="../slider_layout/js/addons/datatables.min.js"></script>

        <script>
        $(document).ready(function() {
            $('#dtBasicExample').DataTable();
            $('.dataTables_length').addClass('bs-select');
            // $('table#tableID').DataTable({
            //  paging: true
            // });
        });
        </script>

    </body>

</html>
