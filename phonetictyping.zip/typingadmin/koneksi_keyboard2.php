﻿<?php
//$con = mysql_connect("69.89.31.93","shininh5_shininh5","Raisonne2012!");

//$con = mysql_connect("localhost","comicedu","Raisonnehostmonster2014!");
//mysql_select_db("comicedu_typing", $con);



//$con = mysql_connect("localhost","root","");
//mysql_select_db("typing", $con);

$con = mysql_connect("localhost","msateaches1","4SupportingIt");
mysql_select_db("typing2", $con);

/*if($con) {
	echo "sukses";
} else {
	echo "gagal";
}*/
?>