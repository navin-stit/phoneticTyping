<?php
require_once("typingadmin/koneksi.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="slider_layout/css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="slider_layout/css/compiled-4.7.6.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="slider_layout/css/style.css" rel="stylesheet">

  <link rel="stylesheet" href="css/phonetic_style.css">

  <link rel="stylesheet" href="<?php echo _DIR_PATH_;?>keyboard/css/jquery.bxslider.css" />

</head>

<body>
